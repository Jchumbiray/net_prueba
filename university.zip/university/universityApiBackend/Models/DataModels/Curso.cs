﻿using System.ComponentModel.DataAnnotations;

namespace universityApiBackend.Models.DataModels
{
    public class Curso : BaseEntity
    {
        [Required, StringLength(128)]
        public string   Name { get; set; } = string.Empty;

        [Required, StringLength(280)]
        public string DescripcionCorta { get; set; } = string.Empty;

        [Required, StringLength(280)]
        public string DescripcionLarga { get; set; } = string.Empty;

        [Required]
        public string PublicObjetivo { get; set; } = string.Empty;

        [Required]
        public string Objetivo { get; set; } = string.Empty;

        [Required]
        public string Requisito { get; set; } = string.Empty;

        [Required]
        public int   Nivel { get; set; }



    }
}
